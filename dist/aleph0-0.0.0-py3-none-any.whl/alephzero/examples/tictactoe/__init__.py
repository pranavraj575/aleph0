from alephzero.examples.tictactoe.game.tictactoe import Toe

__all__=[
    'Toe',
]