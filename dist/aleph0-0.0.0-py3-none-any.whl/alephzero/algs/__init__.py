from alephzero.algs.exhaust_search import Exhasutive

__all__ = [
    'Exhasutive'
]
