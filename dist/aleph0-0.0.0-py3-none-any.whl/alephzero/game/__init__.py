from alephzero.game.game import SubsetGame

__all__ = ['SubsetGame',
           ]
