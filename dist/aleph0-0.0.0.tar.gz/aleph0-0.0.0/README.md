# AlephZero: Extending AlphaZero to Infinite Boards
General implementation of $\aleph_0$, an algorithm that utilizes transformer architectures to solve games with sequential state spaces and action spaces that may include subsets of the state.
